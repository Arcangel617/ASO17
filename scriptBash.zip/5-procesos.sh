#
#DOCUMENTACIÓN:
#
#Autores: Sabadini, Pablo
#         Hernandez, Maximiliano
#         Aquino, Pablo
#         Hipper, Brenda
#         Artiguez, Arcangel
#         Moglia, Franco
#Fecha de Entrega: 28/10/2017 Version 1.0
#Descripción:
#
#Escribir un script 5-procesos.sh que determine si un determinado proceso
#se encuentra en ejecución y muestra información detallada sobre el mismo
#a partir de información almacenada en el directorio proc.
#El nombre del proceso es ingresado por entrada estandar (no argumento).
#El script debera generar dentro del directorio doc un archivo 
#conteniendo la información detallada. El archivo generado deberá
#llamarse de la siguiente manera: proceso-<nombre_proceso>
#
#
#ACLARACIÓN SOBRE ESTE SCRIPT
#
#Antes de ejecutar este script se podría correr por consola el comando "$ps -A" para ver una lista de los procesos que están activos
#y conocer sus nombres, ya que este script está a la espera de un nombre de proceso y no un número, en su primera parte.
#Una vez identificado el proceso el script con el comando pidof y el nombre del proceso lanza otra lista con números
#que el usuario nuevamente podrá elegir para pasar a la parte del contenido
#Otra lista se desplegará, y que está se corresponde con los directorios numerados de la carpeta /proc/ y que a su vez cada
#proceso contiene como información dentro de si mismo.
#Algunos posibles contenidos que se pueden ver con este script pueden ser "status", "stat", "statm". Otros pueden ser directorios
#que contienen más información o bien pueden ser archivos, directorios o enlaces simbolicos a otros directorios fuera de /proc
#que no pueden tener acceso permitido para el usuario o quien lo esté revisando en ese momento.
#
#

#!/bin/bash

DIRECTORIO=./doc/

#
#Vamos a preguntar si existe la carpeta doc/
#y si está vacía para agregar archivos
#

function existeDirectorio(){

if [ -e $DIRECTORIO ]; then
   echo "Existe el directorio."
else
   echo "1-directorios.sh falló al no crear el directorio $DIRECTORIO"
   exit 1
fi

}

#
#Vamos a preguntar si nosotros nos podemos ejecutar
#dentro del directorio
#

function permisoArchivo(){

cd ./bin

if [ -x 5-procesos.sh ]; then
   echo "Tengo permisos de ejecución."
else
   echo "¡Error! No se otorgaron los permisos de ejecución."
   exit 2
fi

}

function validaProcesos(){

#
#Vamos a pedir por stdin el nombre de un proceso
#(para ver una lista de procesos ejecutar ps -A)
#
#

echo "Ingrese el nombre de un proceso:"
read nombre_proceso  # guardamos lo que nos introduce por teclado

ARCHIVOSOPORTE="proceso-<$nombre_proceso>"  #Ubicamos aquí esta variable con el valor, dado que si lo colocamos despues de realizado todos los puntos
                                            #el sistema lo lee como un directorio y no permitirá creación del archivo

#
#Vamos a obtener el PID o ID del proceso que 
#ingresamos por stdin y ver si realmente este proceso existe
#
#

#ps -A | grep $nombre_proceso       #Este comando filtra en forma de lista la cantidad de procesos en forma numérica que pueden estar sucediendo
pidof $nombre_proceso               #De forma similar al anterior, pero solo muestra un par de PID o bien solamente el que se esté ejecutando en el momento

valor=$?             #Guardamos en una variable el posible valor que arroja el comando
                     #no está relacionado con el PID que muestra el comando cuando se le pasa un proceso

#
#Vamos a preguntar si realmente el valor que arroja pertenece a un proceso 
#es decir =0(existe y esta en ejecucion) !=0(no es un proceso activo y si un archivo)
#
#

if [ $valor != 0 ]; then
   echo "Es un archivo virtual con información sobre el sistema." ; PROCESO=$nombre_proceso #Guarda resultado en la variable  
else
   echo "Es un proceso en ejecución." ; PROCESO=$nombre_proceso  #Guarda resultado en la variable
   echo "Elija el o uno de los PID-o-ID del proceso para ver su contenido:"
   read PID         #Esta variable está la espera del valor que ingresemos por stdin y se correspondería a un número de la lista de procesos
fi

}

function crearArchivoInforme(){

cd ./../$DIRECTORIO    #Desde el directorio donde estoy actualmente voy al directorio doc/ para crear el archivo

if [ -f $ARCHIVOSOPORTE ]; then
   echo "¡Error! El archivo \"$ARCHIVOSOPORTE\" ha sido creado antes."
   exit 3
else
   echo "Creando el archivo para el informe."
   touch $ARCHIVOSOPORTE  
fi 

}

#
#Vamos a ver los contenidos de cada proceso ya sea en ejecución o no
#

function muestraContenido(){  #Inicio de la función que hará todo el trabajo de analisis y muestra del proceso

if [ -e /proc/$PROCESO ]; then                           #Para el caso que no sean procesos activos y si archivos virtuales
   echo "La información se encuentra en \"$ARCHIVOSOPORTE\" generado en el directorio \"$DIRECTORIO\"."
   cat /proc/$PROCESO > $ARCHIVOSOPORTE
else
   echo "Mostrando el contenido del $PID."
   ls -F /proc/$PID
   echo "Elija un archivo (podrá ver su contenido en \"$ARCHIVOSOPORTE\" del directorio \"$DIRECTORIO\".)"
   read CONTENIDO
   cat /proc/$PID/$CONTENIDO > $ARCHIVOSOPORTE 
   if [ -d /proc/$PID/$CONTENIDO ]; then
      echo "No se pueden acceder a los directorios de los procesos."
      exit 1
   fi
fi

} #Fin de la función

#
#Llamado a las funciones
#
#

existeDirectorio
permisoArchivo
validaProcesos
crearArchivoInforme
muestraContenido

exit 0
