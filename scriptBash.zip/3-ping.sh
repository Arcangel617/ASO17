#
#DOCUMENTACIÓN:
#
#Autores: Sabadini, Pablo 
#         Hernandez, Maximiliano 
#         Aquino, Pablo 
#         Hipper, Brenda 
#         Artiguez, Arcangel
#         Moglia, Franco
#Fecha de Entrega: 28/10/2017 Version 1.0
#Descripción:
#
#Escribir un script 3-ping.sh que verifique continuamente, cada cierto
#tiempo, la conectividad con un host determinado mediante el comando
#ping. Tanto el host como el tiempo entre verificación deberán ser
#pasados como argumentos del script según el siguiente formato:
#3-ping.sh <IP-o-FQDN> <tiempo>
#El script deberá mostrar por salida estandar un mensaje si hay o no
#conectividad y además generar un archivo dentro del directorio doc
#con la salida del comando ping.
#
#
#
#ACLARACIÓN: puede tardar un poco más de tiempo en realizar la búsqueda

#!/bin/bash

#
#Declaramos algunas variables que nos van a hacer útil durante el script
#
#


DIRECTORIO=./doc

#
#Variables que van a recibir los parámetros que le pasemos al script
#
#

HOST=$1   #IP o FQDN
TIEMPO=$2

#
#Preguntamos si nos pasaron parámatros para poder ejecutar el script
#En caso de no pasar ninguno, finaliza el script
#Si nos pasan parámetros verifica si en realidad pasaron más de los necesarios
#
#

if [ $# -eq 0 ]; then
   echo "Necesito parámetros para ejecutarme."
   exit 4
elif [ $# -gt 2 ]; then
   echo "Solo requiero dos parámetros."
   exit 5
else
   echo "Cantidad de parámetros correcta."
fi

#
#Vamos a preguntar si existe la carpeta doc/
#y si está vacía para agregar archivos
#

function existeDirectorio(){   #Inicio primera función, esto es igual para todos los scripts, con exception de 1-directorios.sh

if [ -e $DIRECTORIO ]; then
   echo "Existe el directorio."
else
   echo "1-directorios.sh falló al crear no crear el directorio $DIRECTORIO."
   exit 1
fi
}

#
#Vamos a preguntar si nosotros nos podemos ejecutar
#dentro del directorio
#

function permisoArchivo(){

cd ./bin

if [ -x 3-ping.sh ]; then
   echo "Tengo permisos de ejecución."
else
   echo "¡Error! No se otorgaron los permisos de ejecución."
   exit 2
fi

}

#
#Vamos a crear el archivo que guardará el informe
#

function crearArchivoInforme(){

cd ./../$DIRECTORIO    #Desde el directorio donde estoy actualmente voy al directorio doc/ para crear el archivo

if [ -f CONECTIVIDAD.info ]; then
   echo "¡Error! El archivo \"CONECTIVIDAD.info\" ha sido creado antes."
   exit 3
else
   echo "Creando el archivo para el informe."
   touch CONECTIVIDAD.info
fi 

}

#
#Vamos a comprobar nuestra conectivdad
#
#

function existeConeccion(){  # Llamado a la función que hará el trabajo de preguntar si hay conexión

COMANDO="ping -c 5 $HOST"    # Esta variable guarda el comando que hará la consulta durante 5 intentos y a la espera del primer parámetro una dirección IP o FQDN
CONT=1                       #Creamos una variable contador

while [ true ]; do    #Iniciamos un loop infinito (true) para realizar el proceso de consulta muchas veces

   sleep $TIEMPO      #Este comando durante cierto tiempo interrumpirá los intentos de consultas para volver a preguntar 
   
   echo "Prueba de conexión Nº $CONT" >> CONECTIVIDAD.info    
   ( echo -e "\n\nFecha:" && date +%d/%m/%y ) >> CONECTIVIDAD.info 

   $COMANDO >> CONECTIVIDAD.info  #Redireccionamos la salida del comando también al archivo informe

   RESULTADO=$( $COMANDO | grep -o 64 )   #Filtramos el resultado de la salida del comando con grep -o "algo", relacionado con la salida del comando
   if [ "$RESULTADO" = 64 ]; then      #Preguntamos si lo que obtemos en igual a lo que se filtro nos mostra que hay conexion; las doble comillas podrian ser opcionales
      echo "No hay conectividad con la IP o FQDN $HOST."
   else
      echo "Hay conectividad con la IP o FQDN $HOST."  
   fi

   let CONT+=1   #Este es el contador que irá incrementando los números de veces que se realizan los intentos completamente
done   #do para iniciar el loop y done para terminar el loop, solo se corta el loop mediante una secuencia de comandos para este caso.

}  #Fin de la función


#
#Llamados de las funciones
#
#

existeDirectorio   
permisoArchivo
crearArchivoInforme
existeConeccion


exit 0  #Codigo de exito del script
