#
#DOCUMENTACIÓN
#
#Autores:   Sabadini, Pablo; 
#           Hernandez, Maximiliano
#           Aquino, Pablo 
#           Hipper, Brenda 
#           Artiguez, Arcangel 
#           Moglia, Franco
#Fecha de Entrega: 28/10/2017 Version 1.0
#Descripción:
#
#Escribir un script 1-directorio.sh que genere la siguiente estructura de directorios:
#
#bin/
#doc/
#script/
#
#etc enlace a /etc
#log enlace a /var/log
#
#Este script deberá controlar que los directorios no existan y deberá informar al usuario cada uno de 
#los directorios creados.-
#
#Luego deberá mover todos los scripts de esta actividad al directorio script, agregar permisos de
#ejecución a los archivos dentro de los directorios bin y script y agregar a la variable PATH
#estos directorios para luego finalizar.-
#
#


#!/bin/bash

#
#Definimos algunas variables que nos serviran en el script
#
#

DIRECTORIO1=./bin/                  #Esta forma donde se ejecuten todos los script se van a crear los directorios
DIRECTORIO2=./doc/
DIRECTORIO3=./script/

COMANDO="/bin/mkdir $DIRECTORIO1 $DIRECTORIO2 $DIRECTORIO3"    #Esta variable es el comando para crear los directorios

function estructuraDirectorio(){     #Inicio de la primera función

if $COMANDO                          #Mientras los directorios no existan serán creados, si existen de antemano se cierra script
   then
   echo "Los directorios $DIRECTORIO1 $DIRECTORIO2 $DIRECTORIO3 fueron creados."
else
   echo "Saliendo de la aplicacion."
   exit 1   #Código de error para una futura documentación
fi

echo "Creando los enlaces simbólicos..."     #Crea los enlaces a los directorios, en el directorio actual donde se están corriendo los scripts
ln -s /etc ./etc
ln -s /var/log ./log
            
}                                            #Fin de la primera función

function copiarArchivos(){                   #Inicio de la segunda función

#cp -r *.sh ./script/
#cp -r ./script/*.* ./bin/

mv *.sh ./script/                            #Mueve todos los archivos que están en el directorio actual a la carpeta script/
cp -r ./script/*.* ./bin/                    #Copia todos los archivos que están en el directorio script/ al directorio bin/ desde la ubicación actual


}                                            #Fin de la segunda función

function darPermisos(){                      #Inicio de la tercera función

if [ -x $DIRECTORIO3 ]; then                                #El condición pregunta si el directorio script/ tiene permisos de ejecución (cuando se lo creo)
   echo "Los archivos de $DIRECTORIO3 ya son ejecutables."  #Mensaje por stdout si hubo exito
   chmod ugo+x $DIRECTORIO3/*.sh                            #Se le otorgan los permisos de ejecución a todos los archivos que son copias a la carpeta script
else
   echo "Error! No tengo permiso de acceso a $DIRECTORIO3."  #Mensaje por stdout si ocurre un error
   exit 2               #Código de error para una futura documentación
fi

if [ -x $DIRECTORIO1 ]; then                                  #La misma condición para el directorio bin/
   chmod 644 $DIRECTORIO1/*.sh
   echo "Los archivos de $DIRECTORIO1 ya son ejecutables."
   chmod ugo+x $DIRECTORIO1/*.sh
else
   echo "Error! No tengo permiso de acceso a $DIRECTORIO1."
   exit 2
fi
}

echo "Creando los directorios..."       #Mensaje por stdout para el usuario avisando que los directorios se están creando si se tuvo existo anteriormente
estructuraDirectorio                    #Llamado a la primera función

echo "Moviendo los archivos a los directorios $DIRECTORIO1 $DIRECTORIO3..."  #Mensahe por stdout para el usuario avisando que los archivos se movieron
copiarArchivos                          #Llamado a la segunda función

echo "Otorgando permisos:"              #Mensaje por stdout para el usuario avisando que se están otorgando los permisos a los archivos si se tuvo exito
darPermisos                             #Llamado a la tercera función

echo "Agregando a la variable PATH los directorios $DIRECTORIO1 y $DIRECTORIO3..."  #Mensaje por stdout para avisar sobre el último paso a realizar con el script

export PATH=$PATH:$PWD/bin/:$PATH/script/    #Se trata de agregar al PATH de Linux los directorios bin/ y script/
echo $PATH              #Mostramos como está el PATH, dentro del script se agregaron los directorios, fuera todo el ambiente no sufrio cambio alguno
exec /bin/bash          #Ejecutamos un nuevo ambiente de bash para que estos cambios en la variable permanezcan temporalmente y llamar a los demás scripts
sleep 300               #Este comando hará que se mantenga por un cierto tiempo los cambios y así poder ejecutar las demás rutinas


exit 0    #Código de existo del script
