#
#DOCUMENTACIÓN
#
#Autores: Sabadini, Pablo 
#         Hernandez, Maximiliano 
#         Aquino, Pablo 
#         Hipper, Brenda 
#         Artiguez, Arcangel 
#         Moglia, Franco
#Fecha de Entrega: 28/10/2017 Version 1.0
#Descripción:
#
#Escribir un script 2-info.sh que genere un archivo INFO.sistema (ubicado en directorio doc antes
#generado) que reuna información del sistema que utilizan. El archivo debe incluir la siguiente
#información, delimitada por títulos descriptivos.-
#
#Fecha del reporte. (date,uptime)
#Versión del equipo y kernel (uname,hostname)
#Versión del S.O.(lsb-release)
#Hardware: Procesador, memoria y periféricos. (proc/cpuinfo,memory,free,lscpu,lsusb,lspci,lsblk)
#Espacio de disco y particiones montadas (fdisk,du,etc/fstab,blkid)
#
# 

#!/bin/bash

#
#Vamos a preguntar si existe la carpeta doc/
#y si está vacía para agregar archivos
#

DIRECTORIO=./doc                #Declaramos una variable que tendra guardado la ubicacion de uno de los directorios a crear

function existeDirectorio(){    #Inicio de la primera función

if [ -e $DIRECTORIO ]; then     #Con -e preguntamos si nuestra variable que creamos existe la estructura de directorios creadas
  echo "Existe el directorio."
else
  echo "1-directorios.sh falló al no crear el directorio $DIRECTORIO."  #Tal vez convenga mejor que lo cree al directorio en vez de mostrar el fallo
  exit 1                        #Codigo de error para una futura documentación
fi

}   #Fin de la primera función

#
#Vamos a preguntar si nosotros nos podemos ejecutar
#dentro del directorio
#

function permisoArchivo(){  #Inicio de la segunda función 

cd ./bin   #Con esto nos estamos ubicando dentro del directorio bin/ a través del script.

if [ -x 2-info.sh ]; then  #-x nos permite saber si el archivo tiene permisos de ejecución.
   echo "Tengo permisos de ejecución."
else
   echo "Error! No se otorgaron los permisos de ejecución."
   exit 2  #Código de error para una futura documentación
fi

}  #Fin de la segunda función

#
#Vamos a crear el archivo que guardará el informe
#

function crearArchivoInforme(){  #Inicio de la tercera función

cd ./../$DIRECTORIO      #Desde el directorio donde estoy actualmente voy al directorio doc/ para crear el archivo.

if [ -f INFO.sistema ]; then          #-f preguntamos si el archivo existe y es un archivo regular
   echo "¡Error! El archivo \"INFO.sistema\" ha sido creado antes."     #Mensaje por stdout; en teoria para evitar duplicidad del archivo
   exit 3             #Código de error para una futura documentación
else
   echo "Creando el archivo para el informe."
   touch INFO.sistema   #Si el archivo no existe, lo cual debería ser así, se lo creará con el comando touch en el directorio doc/
fi

#
#Cargar la información al archivo INFO.sistema
#

(echo -e "\n** FECHA REPORTE:" && date +%d/%m/%Y) > INFO.sistema       #Con date y sus modificadores mostramos la fecha con este tipo de formato dd/mm/aaaa

(echo -e "\n** VERSIÓN DEL EQUIPO:" && uname -m) >> INFO.sistema       #-m junto con el uname muestra la version del equipo

(echo -e "\n** VERSIÓN DEL KERNEL:" && uname -srv) >> INFO.sistema     #-srv junto con uname filtra la salida del comando para mostrar la versión del Kernel

(echo -e "\n** VERSION DEL SO:" && lsb_release -a) >> INFO.sistema     #Este comando junto con -a muestra información detalla de la version del S.O.

(echo -e "\n** HARDWARE: a) INFORMACIÓN SOBRE EL PROCESADOR:" && lscpu |  grep -e "Arquitectura" -e "CPU" -e "ID" -e "Virtualizacion" -e "Caché") >> INFO.sistema

(echo -e "\n             b) INFORMACIÓN SOBRE LA MEMORIA:" && free -h -l -t) >> INFO.sistema #-h junto a free muestra una forma más legible de ver los valores numéricos

(echo -e "\n             c) INFORMACIÓN SOBRE LOS PERIFÉRICOS:" && lsusb ) >> INFO.sistema   #Con este comando mostramos otra información necesaria del sistema

(echo -e "\n             d) OTROS DISPOSITIVOS DEL SISTEMA:" && lspci -nn) >> INFO.sistema   #Una ampliación de la información 

(echo -e "\n** ESPACIO EN DISCO:" && fdisk -l ) >> INFO.sistema  # Este comando depende la distribución linux puede o no pedir permisos de superusuario

(echo -e "\n** INFORMACIÓN AMPLIADA SOBRE EL DISCO:" && lsblk -a -f -l -m -p -S -t && blkid) >> INFO.sistema 

(echo -e "\n** PARTICIONES MONTADAS:" && cat /etc/fstab | grep -e "noatime" ) >> INFO.sistema

}  #Fin de la tercera función

existeDirectorio     #Llamado a la primera función
permisoArchivo       #Llamado a la segunda función
crearArchivoInforme  #Llamado a la tercera función

exit 0 #Código de exito del script
