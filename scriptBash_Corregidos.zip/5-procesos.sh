#!/bin/bash
# DOCUMENTACIÓN:
#
# Autores: Sabadini, Pablo
#          Hernandez, Maximiliano
#          Aquino, Pablo
#          Hipper, Brenda
#          Artiguez, Arcangel
#          Moglia, Franco
# Fecha de Entrega: 28/10/2017 Version 1.0
# Fecha de Correción: 7/11/2017 Version 2.0
#
# Descripción:
#
# Escribir un script 5-procesos.sh que determine si un determinado proceso
# se encuentra en ejecución y muestra información detallada sobre el mismo
# a partir de información almacenada en el directorio proc.
# El nombre del proceso es ingresado por entrada estandar (no argumento).
# El script debera generar dentro del directorio doc un archivo 
# conteniendo la información detallada. El archivo generado deberá
# llamarse de la siguiente manera: proceso-<nombre_proceso>
#
#
# ACLARACIÓN SOBRE ESTE SCRIPT
#
# Antes de ejecutar este script se podría correr por consola el comando "$ps -A" 
# para ver una lista de los procesos que están activos y conocer sus nombres, ya 
# que este script está a la espera de un nombre de proceso y no un número, en su 
# primera parte. Una vez identificado el proceso el script con el comando pidof 
# y el nombre del proceso lanza otra lista con números que el usuario nuevamente 
# podrá elegir para pasar a la parte del contenido. Otra lista se desplegará, y 
# esta se corresponde con los directorios numerados de la carpeta /proc/ y a su 
# vez cada proceso contiene como información dentro de si mismo. Algunos posibles 
# contenidos que se pueden ver con este script pueden ser "status", "stat", "statm". 
# Otros pueden ser directorios que contienen más información o bien pueden ser 
# archivos, directorios o enlaces simbolicos a otros directorios fuera de /proc que 
# no pueden tener acceso permitido para el usuario o quien lo esté revisando en ese 
# momento.
#
########################################################################################################
#
#

#
# Paleta de colores, para las salidas por stdout
# "NC" no color
#
#

RED='\033[1;31m'
GREEN='\033[1;32m'
BROWN='\033[0;33m'
YELLOW='\033[1;33m'
CIAN='\033[1;36m'
NC='\033[0m' 

#
# Se definen las variables de entorno propias ( DIRECTORIO ) 
# para el uso global del script
# "$PWD/../doc" variable de entorno que guarda la ruta 
# absoluta de la ubicación actual y directorio donde se 
# guardará el archivo del informe generado.
#
#

DIRECTORIO="$PWD/../doc"

#
# Se declaran las funciones ( function validaProceso ) 
# que llevaran a cabo una única tarea
# Se pide por stdin el nombre de un proceso
# (para ver una lista de procesos ejecutar ps -A)
# "echo -e" mostrar mensajes por stdout y la opción -e
# para que se puedan utilizar los caracteres de escape
# "read nombre_proceso" comando para leer algo introducido por stdin
# y guardarlo en una variable
# "ARCHIVOSOPORTE" variable que almacenará el nombre del archivo
# y su patrón de nombre
# "pidof $nombre_proceso" comando que arroja por stdout un valor 
# numérico que corresponderá a un identificador de proceso o PID
# estos valores se encuentran en el directorio /proc
# "$?" forma de obtener un resultado arrojado por el comando y de esta
# manera preguntar por verdadero o falso, es decir valor = 0 
# ( existe y está en ejecución ), valor ! = 0 ( no es un proceso activo 
# y si un archivo )
# "PROCESO" variable que contiene el resultado arrojado por el condicional
#
#


function validaProcesos(){

echo -e -n "--> ${BROWN}Ingrese el nombre de un proceso:${NC} "
read nombre_proceso 

ARCHIVOSOPORTE="proceso-<$nombre_proceso>"

#ps -A | grep $nombre_proceso       
echo -e "--> ${YELLOW}IDs: $(pidof $nombre_proceso)${NC}"

valor=$?

if [[ $valor != 0 ]]; then
   echo -e "--> ${BROWN}Es un archivo virtual con\
   información sobre el sistema.${NC}" ; PROCESO=$nombre_proceso   
else
   echo -e "--> ${GREEN}Es un proceso en ejecución.${NC}" ; PROCESO=$nombre_proceso 
   echo -e -n "--> ${BROWN}Elija uno de los PID-o-ID\
   del proceso para ver su contenido:${NC} "
   read PID         
fi

}

#
# Se declaran las funciones ( function existeDirectorio ) 
# que llevaran a cabo una única tarea
# Se "obliga" que exista el directorio doc/
# en la ubicación donde se llame al script,
# fuera de las carpetas bin/ y script/
# "-e" para preguntar sobre la existencia 
# del directorio
# "exit número" codigo de salida del programa ante un fallo y crear
# la futura documentación, o bien ante el valor falso de 
# los condicionales
# \" forma de escapar las dobles comillas por stdout
#
#

function existeDirectorio(){   

if [ -e $DIRECTORIO ]; then     
  echo -e "--> ${GREEN}OK.${NC}"
else
  echo -e "--> ${RED}¡Error de PATH! Estás dentro del \"doc/\" 
  o bien no exite el directorio en este camino. 
  Mostrando PATH:$PWD.${NC}"
  exit 1
fi

}

#
# Se crea el archivo que guardará el informe
# (function crearArchivoInforme)
# "-f" para preguntar si es el fichero existe 
# y es un fichero regular
# "touch $RUTA/Archivo" crea el archivo en la
# ruta especificada 
#
#

function crearArchivoInforme(){


if [ -f $DIRECTORIO/$ARCHIVOSOPORTE ]; then
   echo -e "--> ${RED}¡Error! El archivo \"$ARCHIVOSOPORTE\" ha sido creado antes.${NC}"
   exit 3
else
   echo -e "--> ${BROWN}Creando el archivo para el informe.${NC}"
   touch $DIRECTORIO/$ARCHIVOSOPORTE  
fi 

}

#
# Se ve los contenidos de cada proceso ya sea en ejecución o no
# ( function muestraContenido )
# "cat ruta/archivo" comando para ver el contenido de un archivo 
# en en este caso
# "ls -F ruta/archivo" comando para listar la ruta o directorio
# y ver los archivos que contiene y la opción -F para distinguir
# entre archivos y directorios los cuales se agrega una / ( barra )
# invertida 
# -d para preguntar si es un directorio y si existe
# ">" Con este operador se redirige la salida hacia un archivo
#
#

function muestraContenido(){

if [ -e /proc/$PROCESO ]; then                          
   
   echo -e "--> ${BROWN}La información se encuentra\
   en \"$ARCHIVOSOPORTE\" generado en el directorio \"$DIRECTORIO\"."
   
   cat /proc/$PROCESO > $DIRECTORIO/$ARCHIVOSOPORTE

else
  
   echo -e "--> ${BROWN}Mostrando el contenido del PID ${YELLOW}$PID${NC}"
   ls -F /proc/$PID
   
   echo -e "--> ${BROWN}Elija un archivo (podrá ver su contenido en \"$ARCHIVOSOPORTE\" del directorio \"$DIRECTORIO\".)${NC} "
   echo -e -n  "--> ${BROWN}Archivo:${NC} "
   read CONTENIDO
   
   cat /proc/$PID/$CONTENIDO > $DIRECTORIO/$ARCHIVOSOPORTE 
   
   if [ -d /proc/$PID/$CONTENIDO ]; then
      
      echo -e "--> ${RED}No se pueden acceder 
      a los directorios de los procesos o enlaces simbólicos.${NC}"
      exit 1
   fi
fi

echo -e "--> ${GREEN}Listo.${NC}"
} 

#
# Se llaman a las funciones del script
# "exit 0" codigo de verificación de exito del script y el
# Sistema Operativo
#
#

validaProcesos
existeDirectorio
crearArchivoInforme
muestraContenido

exit 0