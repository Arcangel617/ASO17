#!/bin/bash
# DOCUMENTACIÓN
#
# Autores: Sabadini, Pablo 
#          Hernandez, Maximiliano 
#          Aquino, Pablo 
#          Hipper, Brenda 
#          Artiguez, Arcangel 
#          Moglia, Franco
#
# Fecha de Entrega: 28/10/2017 Version 1.0
# Fecha de Corrección: 7/11/2017 Version 2.0
#
# Descripción:
#
# Escribir un script 2-info.sh que genere un archivo INFO.sistema 
# (ubicado en directorio doc antes generado) que reuna información 
# del sistema que utilizan. El archivo debe incluir la siguiente
# información, delimitada por títulos descriptivos.
#
# Fecha del reporte. (date,uptime)
# Versión del equipo y kernel (uname,hostname)
# Versión del S.O.(lsb-release)
# Hardware: Procesador, memoria y periféricos. 
# (proc/cpuinfo,memory,free,lscpu,lsusb,lspci,lsblk)
# Espacio de disco y particiones montadas (fdisk,du,etc/fstab,blkid)
#
########################################################################################################
#
#

#
# Paleta de colores, para las salidas por stdout
# "NC" no color
#
#

RED='\033[1;31m'
GREEN='\033[1;32m'
BROWN='\033[0;33m'
YELLOW='\033[1;33m'
NC='\033[0m'

#
# Se definen las variables de entorno propias ( DIRECTORIO ) 
# para el uso global del script
# "$PWD/../doc" variable de entorno que guarda la ruta 
# absoluta de la ubicación actual y directorio donde se 
# guardará el archivo del informe generado. 
# 
#

DIRECTORIO="$PWD/../doc"

#
# Se declaran las funciones ( function existeDirectorio ) 
# que llevaran a cabo una única tarea
# Se "obliga" que exista el directorio doc/
# en la ubicación donde se llame al script,
# fuera de las carpetas bin/ y script/
# "-e" para preguntar sobre la existencia 
# del directorio
# "echo -e" mostrar mensajes por stdout y la opción -e
# para que se puedan utilizar los caracteres de escape
# "exit número" codigo de salida del programa ante un fallo y crear
# la futura documentación, o bien ante el valor falso de 
# los condicionales
# \" forma de escapar las dobles comillas por stdout
#
#

function existeDirectorio(){   

if [ -e $DIRECTORIO ]; then     
  echo -e "--> ${GREEN}OK.${NC}"
else
  echo -e "--> ${RED}¡Error de PATH! Estás dentro de \"doc/\" 
  o bien no exite el directorio en este camino. 
  Mostrando PATH:$PWD.${NC}"
  exit 1
fi

}

#
# Se crea el archivo que guardará el informe
# (function crearArchivoInforme)
# "-f" para preguntar si es el fichero existe 
# y es un fichero regular
# "touch $RUTA/Archivo" crea el archivo en la
# ruta especificada 
#
#

function crearArchivoInforme(){ 

if [ -f $DIRECTORIO/INFO.sistema ]; then          
   echo -e "--> ${RED}¡Error! El archivo \"INFO.sistema\" ha sido creado antes.${NC}"
   exit 3             
else
   echo -e "--> ${BROWN}Creando el archivo de informe...${NC}"
   touch $DIRECTORIO/INFO.sistema
fi

}

#
# Se comienza a llenar el archivo informe creado con la información compilada 
# de cada comando
# "&&" comando AND logico para unir en este caso dos sentencias de patrones 
# de comando
# ">" Con este operador se redirige la salida hacia un archivo
# ">>" Lo mismo que el anterior, pero no se sobreescribe la información
# "date date +%d/%m/%Y" comando para obtener una fecha y con formato dd/mm/aaaa
# "uname -m" comando para obtener información del equipo
# "uname -srv" similar al anterior pero con las opciones se obtiene una salida 
# con los datos que solo quiera conocer sin extenderse
# "lsb_release -a" comando para obtener una salida con información del sistema 
# en este caso sobre el Sistema Operativo
# "lscpu | grep -e "Arquitectura" -e "CPU" -e "ID" -e "Virtualizacion" -e "Caché""
# comando para obtener información del procesador, la segunda parte para filtrar 
# la salida y mostrar solamente lo que interesa saber
# "free -h -l -t" comando para obtener información sobre la memoria y las opciones 
# permiten una mejor lectura y entendible para la persona
# "lsusb" comando para obtener una lista en este caso de los perifericos y demás 
# componentes del sistema
# "lspci -nn" comando para complementar lo anterior y tener información más completa 
# del sistema
# "fdisk -l" comando para conocer la información sobre el disco del sistema, puede 
# requerir dependiendo de las distribuciones ejecutarse con "sudo" y se ingrese la 
# contraseña del superusuario
# "lsblk -a -f -l -m -p -S -t && blkid" dos comandos para ampliar la información 
# sobre el discos y las opciones son para ordenarla de de forma que pueda entenderse
# cat /etc/fstab | grep -e "noatime" comando para ver las partciones que estan montadas 
# en el sistema de archivos, y la segunda parte para filtrar la información que no se 
# quiera mostrar en este caso
#
#

function llenarArchivoInformacion(){


echo "** DETALLANDO EL HARDWARE DEL SISTEMA **" > $DIRECTORIO/INFO.sistema

( echo -e "\n** FECHA REPORTE:" && date +%d/%m/%Y ) >> $DIRECTORIO/INFO.sistema       

( echo -e "\n** VERSIÓN DEL EQUIPO:" && uname -m ) >>  $DIRECTORIO/INFO.sistema     

( echo -e "\n** VERSIÓN DEL KERNEL:" && uname -srv ) >> $DIRECTORIO/INFO.sistema   

( echo -e "\n** VERSION DEL SO:" && lsb_release -a ) >> $DIRECTORIO/INFO.sistema     

( echo -e "\n** HARDWARE: a) INFORMACIÓN SOBRE EL PROCESADOR:" && lscpu |  grep -e "Arquitectura" -e "CPU" -e "ID" -e "Virtualizacion" -e "Caché" ) >> $DIRECTORIO/INFO.sistema

( echo -e "\n             b) INFORMACIÓN SOBRE LA MEMORIA:" && free -h -l -t ) >> $DIRECTORIO/INFO.sistema

( echo -e "\n             c) INFORMACIÓN SOBRE LOS PERIFÉRICOS:" && lsusb ) >> $DIRECTORIO/INFO.sistema   

( echo -e "\n             d) OTROS DISPOSITIVOS DEL SISTEMA:" && lspci -nn ) >> $DIRECTORIO/INFO.sistema    

( echo -e "\n** ESPACIO EN DISCO:" && fdisk -l ) >> $DIRECTORIO/INFO.sistema  

( echo -e "\n** INFORMACIÓN AMPLIADA SOBRE EL DISCO:" && lsblk -a -f -l -m -p -S -t && blkid ) >> $DIRECTORIO/INFO.sistema

( echo -e "\n** PARTICIONES MONTADAS:" && cat /etc/fstab | grep -e "noatime" ) >> $DIRECTORIO/INFO.sistema

echo -e "--> ${GREEN}Hecho.${NC}"

}

#
# Se llaman a las funciones del script
# "exit 0" codigo de verificación de exito del script y el
# Sistema Operativo
#
#

echo -e "--> ${BROWN}Comprobando directorios...${NC}"
existeDirectorio
crearArchivoInforme
llenarArchivoInformacion

exit 0