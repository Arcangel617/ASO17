#!/bin/bash
# DOCUMENTACIÓN
#
# Autores:   Sabadini, Pablo; 
#            Hernandez, Maximiliano
#            Aquino, Pablo 
#            Hipper, Brenda 
#            Artiguez, Arcangel 
#            Moglia, Franco
#
# Fecha de Entrega: 28/10/2017 Version 1.0
# Fecha de Correción: 7/11/2017 Version 2.0
# 
# Descripción:
#
# Escribir un script 1-directorio.sh que genere la siguiente 
# estructura de directorios:
#
# bin/
# doc/
# script/
#
# etc enlace a /etc
# log enlace a /var/log
#
# Este script deberá controlar que los directorios no existan 
# y deberá informar al usuario cada uno de los directorios creados.
#
# Luego deberá mover todos los scripts de esta actividad al directorio 
# script, agregar permisos de ejecución a los archivos dentro de los 
# directorios bin y script y agregar a la variable PATH estos 
# directorios para luego finalizar.
#
####################################################################################################################
#
#

#
# Paleta de colores, para las salidas por stdout
# "NC" no color
#
#

RED='\033[1;31m'
GREEN='\033[1;32m'
BROWN='\033[0;33m'
YELLOW='\033[1;33m'
NC='\033[0m'

#
# Se definen las variables de entorno propias ( DIRECTORIO, COMANDO ) 
# para el uso global del script 
# "$PWD" variable de entorno que guarda la ruta absoluta de la ubicación 
# actual
# "/bin/mkdir" ruta absoluta del comando, para crear los directorios
# de la estructura de Directorios.
#
#

DIRECTORIO="$PWD"

COMANDO="/bin/mkdir $DIRECTORIO/bin $DIRECTORIO/doc $DIRECTORIO/script"

#
# Se declaran las funciones ( function estructuraDirectorio ) 
# que llevaran a cabo una única tarea
# "ln -s" para crear los enlaces simbólicos de las ubicaciones
# "exit número" codigo de salida del programa ante un fallo y crear
# la futura documentación, o bien ante el valor falso de los condicionales
# "echo -e" mostrar mensajes por stdout y la opción -e
# para que se puedan utilizar los caracteres de escape
#
#

function estructuraDirectorio(){     

   if $COMANDO                          
      then
      echo -e "--> ${GREEN}Hecho.${NC}"
   else
      echo -e "--> ${RED}No se crearon los directorios.${NC}"
      echo -e "--> ${BROWN}Se sale de la aplicación.${NC}"
      exit 1
   fi

   echo -e "--> ${BROWN}Creando los enlaces simbólicos...${NC}"  
   ln -s /etc ./etc
   ln -s /var/log ./log
   echo -e "--> ${GREEN}Hecho.${NC}"            
}                                            

#
# Se mueven los archivos al directorio script/ y se realiza
# una copia recursiva de todos los archivos al directorio bin/
# ( function copiarArchivos )
# "mv" para mover los archivos desde un origen a su destino
# "cp -r" copiar los archivos de forma recursiva, desde un origen 
# a un destino
# "*.extensión" para mover o copiar solamente los archivos con 
# con esa extensión
# "*.*" Lo mismo que la anterior, pero mueve todos los archivos
# con cualquier extensión, pero en este caso solo los .sh
#
#

function copiarArchivos(){
   mv *.sh ./script/
   cp -r ./script/*.* ./bin/
   echo -e "--> ${GREEN}Hecho.${NC}"
}                                     

#
# Se le otorgan los permisos de ejecución a ambas directorios
# ( function darPermisos )
# "-x" para preguntar si el fichero tiene permisos de ejecución
# "chmod ugo+x" para otorgar a todos permisos de ejecución
#
#


function darPermisos(){                     

if [ -x $DIRECTORIO/script ]; then                                
   chmod ugo+x $DIRECTORIO/script/*.sh                          
else
   echo -e "--> ${RED}Error! No se tienen permisos de acceso a $DIRECTORIO/script."  
   exit 2               
fi

if [ -x $DIRECTORIO1 ]; then
   chmod 644 $DIRECTORIO/bin/*.sh
   chmod ugo+x $DIRECTORIO/bin/*.sh
else
   echo -e "--> ${RED}Error! No se tienen permisos de acceso a $DIRECTORIO/bin.${NC}"
   exit 2
fi

}

#
# Se llaman a las funciones del script
# "export PATH=$PATH:ruta" para agregar a la variable PATH
# los directorios bin/ y script/
# "exec /bin/bash " para correr una nueva instancia
# de bash y así "parchear" el PATH con los directorios
# introducidos
# "sleep 300" para que el comando anterior pueda
# ejecutarse durante el los segundas dados
# "exit 0" codigo de verificación de exito del script y el
# Sistema Operativo
#
#

echo -e "--> ${BROWN}Creando los directorios \"bin\", \"doc\" y \"script\"...${NC}"       
estructuraDirectorio                    

echo -e "--> ${BROWN}Moviendo los archivos a los directorios \"bin\" y \"script\"...${NC}"
copiarArchivos                          

echo -e "--> ${BROWN}Otorgando permisos de ejecución a los scripts...${NC}"              
darPermisos
echo -e "--> ${GREEN}Hecho.${NC}"

echo -e "--> ${BROWN}Agregando a la variable PATH los directorios \"bin/\" y \"script/\"...${NC}"  

export PATH=$PATH:$DIRECTORIO/bin/:$DIRECTORIO/script/   
echo -e "--> ${YELLOW}${PATH}${NC}"
echo -e "--> ${GREEN}Hecho.${NC}"                    
exec /bin/bash
sleep 300               

exit 0