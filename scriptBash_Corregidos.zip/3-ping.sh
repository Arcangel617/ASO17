#!/bin/bash
# DOCUMENTACIÓN:
#
# Autores: Sabadini, Pablo 
#          Hernandez, Maximiliano 
#          Aquino, Pablo 
#          Hipper, Brenda 
#          Artiguez, Arcangel
#          Moglia, Franco
# Fecha de Entrega: 28/10/2017 Version 1.0
# Fecha de Correción: 7/11/2017 Version 2.0
#
# Descripción:
#
# Escribir un script 3-ping.sh que verifique continuamente, cada cierto
# tiempo, la conectividad con un host determinado mediante el comando
# ping. Tanto el host como el tiempo entre verificación deberán ser
# pasados como argumentos del script según el siguiente formato:
# 3-ping.sh <IP-o-FQDN> <tiempo>
# El script deberá mostrar por salida estandar un mensaje si hay o no
# conectividad y además generar un archivo dentro del directorio doc
# con la salida del comando ping.
#
#
# ACLARACIÓN: puede tardar un poco más de tiempo en realizar la búsqueda
#
########################################################################################################
#
#

#
# Paleta de colores, para las salidas por stdout
# "NC" no color
#
#

RED='\033[1;31m'
GREEN='\033[1;32m'
BROWN='\033[0;33m'
YELLOW='\033[1;33m'
CIAN='\033[1;36m'
NC='\033[0m'

#
# Se definen las variables de entorno propias ( DIRECTORIO ) 
# para el uso global del script
# "HOST y TIEMPO" son las variables que almacenarán los 
# parámetros pasados por consola
# "$PWD/../doc" variable de entorno que guarda la ruta 
# absoluta de la ubicación actual y directorio donde se 
# guardará el archivo del informe generado.
# "$1" referencia a una IP o FQDN
# "$2" referencia al tiempo que "dormirá" entre trazas de
# de comprobación
#
#

DIRECTORIO="$PWD/../doc"

HOST=$1   
TIEMPO=$2

#
# Condicional para preguntar sobre los parámetros pasados
# "$#" analiza la totalidad de los parámetros pasados
# "-eq" para referenciar si no hay parámetros pasados, es decir
# si es igual ( equals ) a 0 ( cero )
# "-gt" para referencia si han pasado más parámetros de 
# los necesarios, es decir mayor a ( great than ) 2
# "exit número" codigo de salida del programa ante un fallo y crear
# la futura documentación, o bien ante el valor falso de los 
# condicionales
# "echo -e" mostrar mensajes por stdout y la opción -e
# para que se puedan utilizar los caracteres de escape
#
#

if [ $# -eq 0 ]; then
   echo -e "--> ${RED}ERROR: Se necesitan dos parámentros.${NC}"
   echo -e "--> ${YELLOW}Usage: 3-ping.sh <IP-o-FQDN> <tiempo>${NC}"
   exit 4
elif [ $# -gt 2 ]; then
   echo -e "--> ${RED}ERROR: Se necesitan dos parámentros.${NC}"
   echo -e "--> ${YELLOW}Usage: 3-ping.sh <IP-o-FQDN> <tiempo>${NC}"
   exit 5
else
   echo -e "--> ${BROWN}Comprobando directorios...${NC}"
fi

#
# Se declaran las funciones ( function existeDirectorio ) 
# que llevaran a cabo una única tarea
# Se "obliga" que exista el directorio doc/
# en la ubicación donde se llame al script,
# fuera de las carpetas bin/ y script/
# "-e" para preguntar sobre la existencia 
# del directorio
#
#

function existeDirectorio(){   

if [ -e $DIRECTORIO ]; then     
  echo -e "--> ${GREEN}OK.${NC}"
else
  echo -e "--> ${RED}¡Error de PATH! Estás dentro del \"doc/\" 
  o bien no exite el directorio en este camino. 
  Mostrando PATH:$PWD.${NC}"
  exit 1
fi

}

#
# Se probará la conexión al host y este debería arrojar una respuesta 
# de conexión o sin conexión ( function existeConexion )
# "COMANDO" variable que almacenará el comando en cargado de hacer las 
# pruebas de conexión
# "ping -c número IP o FQDN" hace la comprobación la cantidad de veces 
# que indiquemos a número con la opción -c, y a lo que reciba como 
# parámetro
# "CONT" un contador para fines de adorno a la información que será 
# guardada en el archivo informe creado con el script anterior en doc/
# "while [ condicion ]; do" bucle infinito, es decir siempre será 
# verdadero ( true ) para realizar las trazar de forma repetitiva cada 
# cierto tiempo de descanso
# "sleep tiempo" comando para "dormir" el proceso durante un lapso y 
# volver a realizar el ciclo de comprobación
# "date +%d/%m/%y", comando para obtener una fecha en el formato dd/mm/aaaa
# "grep -o 64" filtra aquella referencia de las trazas de ping que sea 
# igual a 64
# "$RESULTADO = "" en base a lo anterior, si esto coincide se arroja por 
# pantalla que existe la conexión, en caso contrario el mensaje es de 
# no hay conexion
# "let" palabra reservada para el uso de variables que guardaran valores 
# numéricos principalmente
# "done" le dice al script que finalice el loop y vuelva a empezar o bien 
# continuar con la siguiente parte
# ">" Con este operador se redirige la salida hacia un archivo
# ">>" Lo mismo que el anterior, pero no se sobreescribe la información
#
#

function existeConexion(){  

COMANDO="ping -c 5 $HOST"    
CONT=1                       
echo -e "--> ${BROWN}Comprobando conectividad con $HOST${NC}"
echo -e "--> ${CIAN}Ctrl+C p/Finalizar${NC}"
echo -e "\n** CONEXION CON LA RED IP O FQDN $HOST **" >> $DIRECTORIO/INFO.sistema


while [ true ]; do    

   sleep $TIEMPO       
   
   echo "Prueba de conexión Nº $CONT" >> $DIRECTORIO/INFO.sistema
   
   ( echo -e "\n\nFecha:"  &&  date +%d/%m/%y )  >> $DIRECTORIO/INFO.sistema

   $COMANDO >> $DIRECTORIO/INFO.sistema
   
   RESULTADO=$( $COMANDO | grep -o 64 )
   
   if [[ "$RESULTADO" != "" ]]; then      
      echo -e "--> ${YELLOW}Hay conectividad.${NC}"
   else
      echo -e "--> ${RED}No hay conectividad.${NC}"  
   fi

   let CONT+=1   
done  

}  

#
# Se llaman a las funciones del script
# "exit 0" codigo de verificación de exito del script y el
# Sistema Operativo
#
#

existeDirectorio
existeConexion

exit 0