#!/bin/bash
# DOCUMENTACIÓN:
#
# Autores: Sabadini, Pablo
#          Hernandez, Maximiliano
#          Aquino, Pablo 
#          Hipper, Brenda 
#          Artiguez, Arcangel
#          Moglia, Franco
# Fecha de Entrega: 28/10/2017 Version 1.0
# Fecha de Corrección: 7/11/2017 Version 2.0
# 
# Descripción:
#
# Escribir un script 4-buscaArchivos.sh que busque de manera 
# recursiva en un directorio recibido como parametro todos 
# los archivos con una determinada extensión, tambien recibido 
# como parámetro. El script debera verificar que sea un 
# directorio válido, exista y mostrar por salida estandar los 
# archivos encontrados con su ruta completa o absoluta. Ademas 
# deberá generar dentro del directorio doc un archivo conteniendo 
# la misma información. El archivo generado debera llamarse de 
# la siguiente manera:
#
# archivos-<extension>en<directorioBusqueda>
#
########################################################################################################
#
#

#
# Paleta de colores, para las salidas por stdout
# "NC" no color
#
#

RED='\033[1;31m'
GREEN='\033[1;32m'
BROWN='\033[0;33m'
YELLOW='\033[1;33m'
CIAN='\033[1;36m'
NC='\033[0m'

#
# Se definen las variables de entorno propias ( DIRECTORIO ) 
# para el uso global del script
# "$PWD/../doc" variable de entorno que guarda la ruta 
# absoluta de la ubicación actual y directorio donde se 
# guardará el archivo del informe generado.
# "DIRECTORIOBUSQUEDA y EXTENSION" son las variables que almacenarán 
# los parámetros pasados por consola
# "ARCHIVOSOPORTE" variable que almacenará el nombre del archivo
# y su patrón de nombre
# "$1" referencia al primer parámetro, un directo ya sea con
# su ruta absoluta o relativa
# "$2" referencia a la extensión de los archivos que se quieran
# buscar
# "tr / -" comando cuya función en este caso es para reemplazar
# caracteres, las barras de directorios por guiones
# "archivo-<$EXTENSION>en<$(echo $DIRECTORIOBUSQUEDA | tr / -)>"
# patrón para poder crear el nombre del archivo informe de este
# script
#
#

DIRECTORIO="$PWD/../doc"

DIRECTORIOBUSQUEDA=$1
EXTENSION=$2
ARCHIVOSOPORTE="archivo-<$EXTENSION>en<$(echo $DIRECTORIOBUSQUEDA | tr / -)>"

#
# Condicional para preguntar sobre los parámetros pasados
# "$#" analiza la totalidad de los parámetros pasados
# "-eq" para referenciar si no hay pasado nada, es decir
# si es igual ( equals ) a 0 ( cero )
# "-gt" para referencia si han pasado más parámetros de 
# los necesarios, es decir mayor a ( great than ) 2
# "exit número" codigo de salida del programa ante un fallo y crear
# la futura documentación, o bien ante el valor falso de los 
# condicionales
# "echo -e" mostrar mensajes por stdout y la opción -e
# para que se puedan utilizar los caracteres de escape
#
#

if [ $# -eq 0 ]; then
   echo -e "--> ${RED}ERROR: Se necesitan dos parámentros.${NC}"
   echo -e "--> ${YELLOW}Usage: 4-buscaArchivos.sh <DIRECTORIO> <EXTENSION>${NC}"
   exit 4
elif [ $# -gt 2 ]; then
   echo -e "--> ${RED}ERROR: Se necesitan dos parámentros.${NC}"
   echo -e "--> ${YELLOW}Usage: 4-buscaArchivos.sh <DIRECTORIO> <EXTENSION>${NC}"
else
   echo -e "--> ${BROWN}Comprobando directorios...${NC}"
fi

#
# Se declaran las funciones ( function existeDirectorio ) 
# que llevaran a cabo una única tarea
# Se "obliga" que exista el directorio doc/
# en la ubicación donde se llame al script,
# fuera de las carpetas bin/ y script/
# "-e" para preguntar sobre la existencia 
# del directorio
# \" forma de escapar las dobles comillas por stdout
#
#

function existeDirectorio(){   

if [ -e $DIRECTORIO ]; then     
  echo -e "--> ${GREEN}OK.${NC}"
else
  echo -e "--> ${RED}¡Error de PATH! Estás dentro del \"doc/\" 
  o bien no exite el directorio en este camino. 
  Mostrando PATH:$PWD.${NC}"
  exit 1
fi

}

#
# Se crea el archivo que guardará el informe
# ( function crearArchivoInforme )
# "-f" para preguntar si es el fichero existe 
# y es un fichero regular
# "touch $RUTA/Archivo" crea el archivo en la
# ruta especificada 
#
#

function crearArchivoInforme(){

  if [ -f $DIRECTORIO/$ARCHIVOSOPORTE ]; then
     echo -e "--> ${RED}¡Error! El archivo \"$ARCHIVOSOPORTE\" ha sido creado antes.${NC}"
     exit 3
  else
    echo -e "--> ${BROWN}Creando el archivo para el informe.${NC}"
    touch $DIRECTORIO/$ARCHIVOSOPORTE
    echo -e "--> ${GREEN}Hecho.${NC}"
  fi
}

#
# Se realiza la busqueda de los archivos en el directorio 
# ( function encuentraExtensionDirectorio ) con la extensión y
# ruta del directorio pasada
# 'find $DIRECTORIOBUSQUEDA -type f -iname "$EXTENSION" -print 2>&1 | fgrep -v "Permiso denegado"'
# patrón para realizar la busqueda 
# "find ruta" comando para buscar en el directorio dado
# -type f -iname "$EXTENSION" opciones del comando find para
# filtrar solamente los archivos con la extensión que quiera
# '-print 2>&1 | fgrep -v "Permiso denegado"' de esta forma se
# "ocultan" a la vista del stdout todos aquelos directorios o ficheros
# con permiso denegado, cuyo acceso solo es posible siendo root
# "&&" comando AND logico para unir en este caso dos sentencias de
# patrones de comando, la primera para mostrar por stdout y la segunda
# para una redirección hacia el archivo de informe
# ">>" Con este operador se redirige la salida hacia un archivo
# sin sobre-escribir ninguna otra información pueda estar en el archivo
#

function encuentraExtensionDirectorio(){  

echo -e "--> ${BROWN}Buscando archivos \"$EXTENSION\" en \"$DIRECTORIOBUSQUEDA\".${NC}"
if [ -d $DIRECTORIOBUSQUEDA ]; then 
  echo -e "--> ${GREEN}El directorio existe y es válido.${NC}"
  ( find $DIRECTORIOBUSQUEDA -type f -iname "$EXTENSION" -print 2>&1 | fgrep -v "Permiso denegado" ) && 
  ( find $DIRECTORIOBUSQUEDA -type f -iname "$EXTENSION" -print 2>&1 | fgrep -v "Permiso denegado" ) >> $DIRECTORIO/$ARCHIVOSOPORTE 
else
   echo -e "--> ${RED}No existe el directorio.${NC}"
   exit 1 
fi

}

#
# Se llaman a las funciones del script
# "exit 0" codigo de verificación de exito del script y el
# Sistema Operativo
#
#

existeDirectorio
crearArchivoInforme
encuentraExtensionDirectorio

exit 0